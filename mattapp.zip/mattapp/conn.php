<?php 

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tutorial_db";

try{

	$conn = new pdo("mysql:host=$servername;dbname=$dbname",$username,$password);

	$conn->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

	// echo "connected successfully";

}catch(PDOException $e){

	echo "not connected".$e->getMessage();
}




?>