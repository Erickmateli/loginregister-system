<?php 
require_once('conn.php');

 if (isset($_POST['submit'])) {
	
try{

	$stmt = $conn->prepare("INSERT INTO reports(sacco,numberplate,carname,casetype,message)
							 VALUES(:sacco,:numberplate,:carname,:casetype,:message)");

	$sacco = $_POST['Sacco'];

	$numberplate = $_POST['numberplate'];

	$carname = $_POST['carname'];

	$casetype = $_POST['case'];

	$message = $_POST['Message'];


	$stmt->bindParam(':sacco',$sacco);

	$stmt->bindParam(':numberplate',$numberplate);

	$stmt->bindParam(':carname',$carname);

	$stmt->bindParam(':casetype',$casetype);

	$stmt->bindParam(':message',$message);

	$stmt->execute();

	 echo "case successfully reported";


}catch(PDOException $e){

	 echo "case not successfully reported".$e->getMessage();


}


}

?>

<!DOCTYPE html>
<html>
<head>
	<title>report</title>
	 <link rel="stylesheet" href="css/style.css">
     <script type="text/javascript" src="validate/jquery.min.js"></script>
</head>
<body>
	<div id="report">
	<h1>REPORT A CASE </h1>
	<form method="post" action="forms.php" id="reports">
<ul class="form-style-1">
    
    <li>
        <label id="sacco_required" for="sacconame">Sacco name<span class="required">*</span></label>
        <input type="text" name="Sacco" id="sacco" class="field-long"  />
        <label class="errors" for="sacconame" id="sacco_errors">This field is required</label>   
    </li>
     <li>
        <label for="numberplate">Number plate<span class="required">*</span></label>
        <input type="text" name="numberplate" id="numberplate" class="field-long"  />
        <label class="errors" for="numberplate" id="plate_errors">This field is required</label> 
    </li>
     <li>
        <div>
        <label for="carname">Car name<span class="required">*</span></label>
        <input type="text" name="carname" class="field-long" id="carname" />
        <label class="errors" for="carname" id="car_errors">This field is required</label> 
       </div>

    </li>
    <li>
        <label>Complaint <span class="required">*</span></label>
        <select name="case" class="field-select"  >
        <option value=" ">Select One</option>
        <option value="overspeeding">overspeeding</option>
        <option value="conductors misbehaviour">conductors misbehaviour</option>
        <option value="overcharging">overcharging</option>
        <option value="overcharging">poor services</option>
        <option value="overcharging">mishandling of passangers goods</option>
        <option value="overcharging">being dropped at the wrong stage</option>
        <option value="overcharging">hijacking</option>
        </select>
    </li>
    <li>
        <label>Your Message <span class="required">*</span></label>
        <textarea type="text" name="Message" id="field5" class="field-long field-textarea" required></textarea>
       <label class="errors" for="message" id="message_errors">This field is required</label> 
    </li>
    <li>
        <button type="submit" name="submit" class="button" id="submit">submit</button>
    </li>
</ul>
</form>
</div>
    <script type="text/javascript">
        $(document).ready(function(){
            $(".errors").hide();
            $(".button").click(function(){
                $(".errors").hide();

                var sacconame = $("input#sacco").val();

                if(sacconame===""){

                    $("label#sacco_errors").show();
                    $("input#sacco").focus();
                    return false;
                }

                var numberplate = $("input#numberplate").val();

                if(numberplate === ""){

                    $("label#plate_errors").show();
                    $("input#numberplate").focus();
                    return false;
                }

                var carname = $("input#carname").val();

                if(carname===""){

                    $("label#car_errors").show();
                    $("input$carname").focus();
                    return false;
                }

            });
        });
    </script>
     </body>
</html>
