<?php

require_once('login.php');

$hash = password_hash($password,PASSWORD_DEFAULT);

if(password_verify($password,$hash)){

	echo "success";
}else{

	echo "sorry";
}

if (password_needs_rehash($hash, PASSWORD_DEFAULT, ['cost' => 12])) {
    // the password needs to be rehashed as it was not generated with
    // the current default algorithm or not created with the cost
    // parameter 12
    $hash = password_hash($password, PASSWORD_DEFAULT, ['cost' => 12]);

    // don't forget to store the new hash!
}


 ?>