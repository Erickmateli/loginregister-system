<?php

require_once('session.php');

echo 'welcome '.$usersession[0]['Name'];
echo "<br><a href='logout.php'>Logout</a>";


 ?>